# Quillbase on Vercel (Node only)

Files, all at the TOP LEVEL of the repo:
  package.json, vercel.json, README.md
  public/index.html      the site
  api/generate.js        writes the article (Anthropic API, streamed)
  api/research.js        fetches background facts (Wikipedia) and related terms (Datamuse)

Remove every other file from the repo, especially .py files, requirements.txt and anything from public-apis.
Those make Vercel treat the project as Python (PYTHON_ENTRYPOINT_NOT_FOUND).

Settings: Framework Preset = Other. Root Directory = empty.

Environment Variables (Settings > Environment Variables, key names in capitals are fine there), then Redeploy:
  ANTHROPIC_API_KEY   your key from console.anthropic.com
  APP_PASSCODE        a code you choose; the site asks for it once per browser
  ANTHROPIC_MODEL     optional, defaults to claude-sonnet-5-5

Wikipedia and Datamuse need no key. Credits, documents and voice files live in each visitor's browser.
