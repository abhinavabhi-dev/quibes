var UA = { "User-Agent": "Quillbase/1.0 (article research)" };

function get(url) {
  return fetch(url, { headers: UA, signal: AbortSignal.timeout(6000) }).then(function (r) {
    if (!r.ok) throw new Error("http " + r.status);
    return r.json();
  });
}

module.exports = async function (req, res) {
  var code = process.env.APP_PASSCODE;
  if (!code) { res.statusCode = 503; return res.end("Server is not configured"); }
  if (req.headers["x-access-code"] !== code) { res.statusCode = 401; return res.end("Unauthorized"); }
  var q = String((req.query && req.query.q) || "").trim().slice(0, 150);
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  if (!q) return res.end(JSON.stringify({ facts: [], related: [] }));
  var facts = [], related = [];
  await Promise.allSettled([
    get("https://en.wikipedia.org/w/rest.php/v1/search/page?limit=3&q=" + encodeURIComponent(q)).then(async function (s) {
      var pages = (s.pages || []).slice(0, 2);
      await Promise.allSettled(pages.map(function (p) {
        return get("https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(p.key)).then(function (d) {
          if (d.extract) facts.push({
            title: d.title,
            extract: d.extract.slice(0, 700),
            url: (d.content_urls && d.content_urls.desktop && d.content_urls.desktop.page) || ("https://en.wikipedia.org/wiki/" + encodeURIComponent(p.key))
          });
        });
      }));
    }),
    get("https://api.datamuse.com/words?max=12&ml=" + encodeURIComponent(q)).then(function (w) {
      related = w.map(function (x) { return x.word; });
    })
  ]);
  res.end(JSON.stringify({ facts: facts, related: related }));
};
